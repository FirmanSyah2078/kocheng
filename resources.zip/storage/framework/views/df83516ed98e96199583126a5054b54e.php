<footer class="bg-primary text-white py-8 mt-auto border-t border-white/10">
    <div class="container mx-auto px-4 text-center">
        <p class="font-serif text-xl text-accent mb-1">Meowland</p>
        <p class="text-sm text-white/60">&copy; <?php echo e(date('Y')); ?> Meowland Pet Shop. All rights reserved.</p>
    </div>
</footer><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/components/footer.blade.php ENDPATH**/ ?>