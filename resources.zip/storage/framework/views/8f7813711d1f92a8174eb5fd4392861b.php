<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($data->invoice_number); ?> <?php $__env->endSlot(); ?>

    <a href="<?php echo e(route('dashboard.admin.index', ['tab' => 'transactions'])); ?>" class="text-sm text-secondary hover:text-primary">&larr; Kembali</a>

    <div class="grid grid-cols-2 gap-4 my-6 bg-white p-6 rounded-2xl shadow-sm">
        <div><p class="text-xs text-secondary">Pelanggan</p><p class="font-semibold"><?php echo e($data->user->name); ?></p></div>
        <div><p class="text-xs text-secondary">Metode Pembayaran</p><p class="font-semibold uppercase"><?php echo e($data->payment_method); ?></p></div>
        <div><p class="text-xs text-secondary">Status</p><p class="font-semibold capitalize"><?php echo e($data->status); ?></p></div>
        <div><p class="text-xs text-secondary">Tanggal</p><p class="font-semibold"><?php echo e($data->created_at->format('d M Y, H:i')); ?></p></div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <th class="th-dashboard">Produk</th><th class="th-dashboard text-center">Jumlah</th><th class="th-dashboard">Harga Satuan</th><th class="th-dashboard">Subtotal</th>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <?php $__currentLoopData = $data->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="td-dashboard"><?php echo e($item->product->name ?? 'Produk dihapus'); ?></td>
                    <td class="td-dashboard text-center"><?php echo e($item->quantity); ?></td>
                    <td class="td-dashboard">Rp <?php echo e(number_format($item->price_at_sale, 0, ',', '.')); ?></td>
                    <td class="td-dashboard">Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760)): ?>
<?php $attributes = $__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760; ?>
<?php unset($__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760)): ?>
<?php $component = $__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760; ?>
<?php unset($__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760); ?>
<?php endif; ?>

    <div class="mt-6 text-right">
        <p class="text-secondary">Total: <span class="text-primary font-bold"><?php echo e($data->formatted_total_amount); ?></span></p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/dashboard/admin/transactions-detail.blade.php ENDPATH**/ ?>