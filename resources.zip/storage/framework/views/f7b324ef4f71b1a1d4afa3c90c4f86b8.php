<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product', 'quantity']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product', 'quantity']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $categoryIcons = [
        'makanan' => 'icon-[game-icons--canned-fish]',
        'obat' => 'icon-[mdi--medicine-bottle]',
        'alat' => 'icon-[mdi--bowl-mix]',
        'mainan' => 'icon-[mdi--toy-brick]',
    ];
    $icon = $categoryIcons[strtolower($product->category->name ?? '')] ?? 'icon-[mdi--paw]';
?>

<div class="flex justify-between items-center bg-white rounded-2xl border border-black/5 px-5 py-4">
    <div class="flex items-center gap-4">
        <div class="w-16 h-16 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
            <span class="<?php echo e($icon); ?> text-2xl text-accent"></span>
        </div>
        <div>
            <p class="font-bold text-primary text-sm"><?php echo e($product->name); ?></p>
            <p class="text-xs text-secondary mb-1"><?php echo e($product->category->name ?? '-'); ?></p>
            <p class="text-primary font-semibold text-sm"><?php echo e($product->formatted_price); ?></p>
        </div>
    </div>

    <div class="flex flex-col items-end gap-2">
        <form action="<?php echo e(route('dashboard.user.cart.remove', $product)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="text-danger text-xs font-semibold hover:underline">Hapus</button>
        </form>

        <div class="flex items-center gap-2">
            <form action="<?php echo e(route('dashboard.user.cart.update', [$product, 'minus'])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="w-7 h-7 rounded-lg bg-neutral hover:bg-black/5 flex items-center justify-center text-sm font-bold <?php echo e($quantity <= 1 ? 'opacity-30 pointer-events-none' : ''); ?>">−</button>
            </form>
            <span class="font-bold text-sm w-4 text-center"><?php echo e($quantity); ?></span>
            <form action="<?php echo e(route('dashboard.user.cart.update', [$product, 'plus'])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="w-7 h-7 rounded-lg bg-neutral hover:bg-black/5 flex items-center justify-center text-sm font-bold">+</button>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/components/dashboard/cart-item.blade.php ENDPATH**/ ?>