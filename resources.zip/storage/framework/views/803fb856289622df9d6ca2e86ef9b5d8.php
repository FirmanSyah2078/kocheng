<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Login - Meowland <?php $__env->endSlot(); ?>

    <section class="py-20 px-6 flex justify-center">
        <div class="bg-white p-8 rounded-2xl shadow border-t-4 border-accent w-full max-w-md">
            <h1 class="font-serif text-3xl text-primary text-center mb-8">Login ke Meowland</h1>

            <?php if($errors->any()): ?>
                <div class="mb-6 bg-danger/10 text-danger text-sm rounded-xl p-4">
                    <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('login.attempt')); ?>" method="POST" class="space-y-5">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="block text-sm font-semibold text-secondary mb-2">Email</label>
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="w-full px-4 py-3 rounded-xl border border-black/10 focus:ring-2 focus:ring-accent outline-none" placeholder="email@contoh.com">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-secondary mb-2">Password</label>
                    <input type="password" name="password" class="w-full px-4 py-3 rounded-xl border border-black/10 focus:ring-2 focus:ring-accent outline-none" placeholder="••••••••">
                </div>
                <button type="submit" class="w-full bg-primary text-white py-3 rounded-xl font-bold hover:opacity-90 transition">
                    Masuk
                </button>
            </form>

            <p class="mt-6 text-center text-sm text-secondary">
                Belum punya akun?
                <a href="<?php echo e(route('signup')); ?>" class="text-accent font-bold hover:underline">Daftar sekarang</a>
            </p>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/auth/login.blade.php ENDPATH**/ ?>