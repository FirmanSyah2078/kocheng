<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Tentang Kami - Meowland <?php $__env->endSlot(); ?>

    <section class="font-sans-landing bg-neutral-landing max-w-4xl mx-auto px-6 py-20 text-center rounded-3xl">
        <h1 class="font-bold text-4xl text-primary-landing mb-8">Kisah Meowland</h1>
        <div class="bg-white p-10 rounded-2xl shadow-sm text-left leading-relaxed text-secondary-landing">
            <p class="mb-6">
                Meowland lahir dari keinginan untuk memberikan kemudahan bagi para pecinta kucing.
                Kami paham waktumu berharga, tapi kesehatan dan kebahagiaan anabul tetap prioritas utama.
            </p>
            <p>
                Dengan konsep <strong class="text-primary-landing">"Klik Meowland, Ambil di Toko"</strong>,
                kamu cukup pesan dari ponsel, datang ke toko, dan bawa pulang kebahagiaan untuk kucingmu.
            </p>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/about.blade.php ENDPATH**/ ?>