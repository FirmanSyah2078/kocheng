<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Meowland - Klik, Pesan, Ambil! <?php $__env->endSlot(); ?>

    <div class="font-sans-landing bg-neutral-landing">
        <section class="max-w-7xl mx-auto px-6 lg:px-12 py-20 flex flex-col lg:flex-row items-center gap-12">
            <div class="lg:w-3/5">
                <h1 class="text-5xl lg:text-6xl font-bold text-primary-landing leading-tight mb-6">
                    Kebutuhan Anabul, <span class="text-accent-landing">Satu Klik Selesai.</span>
                </h1>
                <p class="text-lg text-secondary-landing mb-8 max-w-lg">
                    Pesan makanan, mainan, dan obat kucing favoritmu secara online.
                    Gak perlu antre, tinggal datang dan ambil di toko!
                </p>
                <a href="<?php echo e(route('signup')); ?>" class="inline-flex items-center gap-2 bg-primary-landing text-white px-8 py-4 rounded-full font-bold hover:scale-105 transition-transform shadow">
                    <span class="icon-[mdi--paw] text-xl"></span>
                    Klik Meowland Sekarang
                </a>
            </div>
            <div class="lg:w-2/5 flex justify-center">
                <div class="w-72 h-72 rounded-full bg-accent-landing/10 border-4 border-dashed border-accent-landing flex items-center justify-center">
                    <span class="text-accent-landing text-center px-4">Foto Kucing Disini</span>
                </div>
            </div>
        </section>

        <section class="bg-white/60 py-20">
            <div class="text-center mb-14">
                <h2 class="text-3xl font-bold text-primary-landing mb-3">Kategori Favorit</h2>
                <div class="w-16 h-1 bg-accent-landing mx-auto"></div>
            </div>

            <div class="max-w-6xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-6 px-6">
                <div class="bg-white p-6 rounded-2xl border-b-4 border-accent-landing shadow-sm hover:shadow-md transition text-center">
                    <span class="icon-[mdi--toy-brick] text-4xl text-accent-landing mb-2 block mx-auto"></span>
                    <p class="font-bold text-primary-landing">Mainan</p>
                </div>
                <div class="bg-white p-6 rounded-2xl border-b-4 border-secondary-landing shadow-sm hover:shadow-md transition text-center">
                    <span class="icon-[mdi--bowl-mix] text-4xl text-secondary-landing mb-2 block mx-auto"></span>
                    <p class="font-bold text-primary-landing">Makanan</p>
                </div>
                <div class="bg-white p-6 rounded-2xl border-b-4 border-danger-landing shadow-sm hover:shadow-md transition text-center">
                    <span class="icon-[mdi--medicine-bottle] text-4xl text-danger-landing mb-2 block mx-auto"></span>
                    <p class="font-bold text-primary-landing">Obat</p>
                </div>
                <div class="bg-white p-6 rounded-2xl border-b-4 border-primary-landing shadow-sm hover:shadow-md transition text-center">
                    <span class="icon-[game-icons--canned-fish] text-4xl text-primary-landing mb-2 block mx-auto"></span>
                    <p class="font-bold text-primary-landing">Alat</p>
                </div>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/home.blade.php ENDPATH**/ ?>