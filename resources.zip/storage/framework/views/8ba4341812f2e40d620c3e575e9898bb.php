<div>
    <div class="overflow-hidden rounded-xl border border-black/10">
        <table class="w-full bg-white">
            <thead>
                <tr class="bg-primary text-white [&>th]:text-left">
                    <?php echo e($header); ?>

                </tr>
            </thead>
            <tbody>
                <?php echo e($body); ?>

            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/components/dashboard/table.blade.php ENDPATH**/ ?>