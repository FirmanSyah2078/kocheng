<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Katalog Produk - Meowland <?php $__env->endSlot(); ?>

    <div class="max-w-7xl mx-auto px-6 py-10">

        <?php if(session('success')): ?>
            <div id="cart-alert-container" class="added-cart-indicator fixed right-0 z-50 left-0 group pointer-events-none">
                <div
                    class="w-fit h-fit p-5 rounded-2xl bg-primary text-white absolute right-10 top-4 transition-all duration-500 ease-in-out opacity-0 translate-x-full invisible group-[.success]:opacity-100 group-[.success]:visible group-[.success]:translate-x-0 shadow-lg">
                    <p><?php echo e(session('success')); ?></p>
                </div>
            </div>
        <?php endif; ?>

        <section class="flex flex-col md:flex-row w-full justify-between items-start md:items-center gap-5 mb-8">
            <div>
                <h1 class="font-serif text-3xl font-bold text-primary">Katalog Produk</h1>
                <p class="text-secondary">Semua kebutuhan anabul kesayanganmu ada di sini!</p>
            </div>

            <div id="categories-wrapper" class="relative inline-block group">

                <?php
                    $selectedCategories = request('categories', []);
                ?>

                <form action="<?php echo e(route('dashboard.user.products')); ?>" method="GET" id="filter-form">

                    <button type="button"
                        class="categories flex items-center cursor-pointer border-t border-black/10 shadow rounded-2xl py-2 px-4 bg-white transition-all duration-500 group-[.menu-open]:rounded-b-none">
                        Kategori
                        <?php if(count($selectedCategories) > 0): ?>
                            <span class="bg-accent text-primary rounded-full px-2 py-0.5 text-xs ml-2 font-bold">
                                <?php echo e(count($selectedCategories)); ?>

                            </span>
                        <?php endif; ?>
                        <span
                            class="icon-[mdi--keyboard-arrow-down] categories-arrow text-xl transition-transform duration-500 ml-2"></span>
                    </button>

                    <div
                        class="categories-option z-10 absolute shadow-lg p-4 gap-2 transition-all duration-500 ease-in-out flex flex-col opacity-0 invisible -translate-y-2 w-56 bg-white top-full right-0 rounded-b-2xl
                        group-[.menu-open]:opacity-100 group-[.menu-open]:visible group-[.menu-open]:translate-y-0">

                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="border-b border-black/10 py-2">
                                <label class="flex items-center gap-2 cursor-pointer text-sm">
                                    <input type="checkbox" name="categories[]" value="<?php echo e($category->slug); ?>"
                                        class="filter-checkbox" <?php if(in_array($category->slug, $selectedCategories)): echo 'checked'; endif; ?>>
                                    <?php echo e($category->name); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-xs text-secondary py-2">Belum ada kategori.</p>
                        <?php endif; ?>

                        <button type="submit"
                            class="bg-primary text-white py-2 mt-2 rounded-lg hover:opacity-90 transition text-sm font-bold">
                            Terapkan Filter
                        </button>
                    </div>
                </form>
            </div>
        </section>

        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if (isset($component)) { $__componentOriginal86f4292c4da4effe98ae2f628c5f47d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal86f4292c4da4effe98ae2f628c5f47d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal86f4292c4da4effe98ae2f628c5f47d2)): ?>
<?php $attributes = $__attributesOriginal86f4292c4da4effe98ae2f628c5f47d2; ?>
<?php unset($__attributesOriginal86f4292c4da4effe98ae2f628c5f47d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal86f4292c4da4effe98ae2f628c5f47d2)): ?>
<?php $component = $__componentOriginal86f4292c4da4effe98ae2f628c5f47d2; ?>
<?php unset($__componentOriginal86f4292c4da4effe98ae2f628c5f47d2); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-secondary col-span-full text-center py-12">Belum ada produk di kategori ini.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/dashboard/user/products.blade.php ENDPATH**/ ?>