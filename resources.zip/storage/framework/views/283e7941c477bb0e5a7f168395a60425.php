<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Kelola <?php echo e(ucfirst($tab)); ?> <?php $__env->endSlot(); ?>

    <section class="max-w-7xl mx-auto px-6 py-10">
        <?php if(session('success')): ?>
            <div class="mb-6 rounded-xl p-4 text-sm" style="background: color-mix(in srgb, #7C9473 12%, white); color:#4d5d47;">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="flex gap-5 mb-6 border-b border-black/10">
            <?php $__currentLoopData = ['users' => 'Users', 'categories' => 'Categories', 'products' => 'Products', 'transactions' => 'Transactions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('dashboard.admin.index', ['tab' => $key])); ?>"
                    class="pb-3 text-sm font-semibold <?php echo e($tab === $key ? 'text-primary border-b-2 border-accent' : 'text-secondary hover:text-primary'); ?>">
                    <?php echo e($label); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if (isset($component)) { $__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('header', null, []); ?> 
                <?php if($tab === 'users'): ?>
                    <th class="th-dashboard text-center">ID</th>
                    <th class="th-dashboard text-left">Nama</th>
                    <th class="th-dashboard text-left">Email</th>
                    <th class="th-dashboard text-center">Role</th>
                    <th class="th-dashboard text-center">Status</th>
                    <th class="th-dashboard text-center">Aksi</th>
                <?php elseif($tab === 'categories'): ?>
                    <th class="th-dashboard text-center">ID</th>
                    <th class="th-dashboard text-left">Nama</th>
                    <th class="th-dashboard text-center">Total Produk</th>
                    <th class="th-dashboard text-center">Status</th>
                    <th class="th-dashboard text-center">Aksi</th>
                <?php elseif($tab === 'products'): ?>
                    <th class="th-dashboard text-center">ID</th>
                    <th class="th-dashboard text-left">Kategori</th>
                    <th class="th-dashboard text-left">SKU</th>
                    <th class="th-dashboard text-left">Nama</th>
                    <th class="th-dashboard text-left">Harga</th>
                    <th class="th-dashboard text-center">Stok</th>
                    <th class="th-dashboard text-center">Status</th>
                    <th class="th-dashboard text-center">Aksi</th>
                <?php elseif($tab === 'transactions'): ?>
                    <th class="th-dashboard text-left">Invoice</th>
                    <th class="th-dashboard text-left">Pelanggan</th>
                    <th class="th-dashboard text-left">Total</th>
                    <th class="th-dashboard text-center">Status</th>
                    <th class="th-dashboard text-center">Metode</th>
                    <th class="th-dashboard text-center">Aksi</th>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('body', null, []); ?> 
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-neutral transition">
                        <?php if($tab === 'users'): ?>
                            <td class="td-dashboard text-center"><?php echo e($d->id); ?></td>
                            <td class="td-dashboard"><?php echo e($d->name); ?></td>
                            <td class="td-dashboard"><?php echo e($d->email); ?></td>
                            <td class="td-dashboard text-center capitalize"><?php echo e($d->role); ?></td>
                            <td class="td-dashboard text-center capitalize"><?php echo e($d->status); ?></td>
                            <td class="td-dashboard text-center space-x-2">
                                <a href="<?php echo e(route('dashboard.admin.users.edit', $d)); ?>" class="text-primary hover:underline">Edit</a>
                                <form action="<?php echo e(route('dashboard.admin.users.destroy', $d)); ?>" method="POST" class="inline" onsubmit="return confirm('Nonaktifkan <?php echo e($d->name); ?>?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-danger hover:underline">Nonaktifkan</button>
                                </form>
                            </td>
                        <?php elseif($tab === 'categories'): ?>
                            <td class="td-dashboard text-center"><?php echo e($d->id); ?></td>
                            <td class="td-dashboard"><?php echo e($d->name); ?></td>
                            <td class="td-dashboard text-center"><?php echo e($d->products_count); ?></td>
                            <td class="td-dashboard text-center capitalize"><?php echo e($d->status); ?></td>
                            <td class="td-dashboard text-center space-x-2">
                                <a href="<?php echo e(route('dashboard.admin.categories.edit', $d)); ?>" class="text-primary hover:underline">Edit</a>
                                <form action="<?php echo e(route('dashboard.admin.categories.destroy', $d)); ?>" method="POST" class="inline" onsubmit="return confirm('Nonaktifkan <?php echo e($d->name); ?>?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-danger hover:underline">Nonaktifkan</button>
                                </form>
                            </td>
                        <?php elseif($tab === 'products'): ?>
                            <td class="td-dashboard text-center"><?php echo e($d->id); ?></td>
                            <td class="td-dashboard"><?php echo e($d->category->name ?? '-'); ?></td>
                            <td class="td-dashboard"><?php echo e($d->sku); ?></td>
                            <td class="td-dashboard"><?php echo e($d->name); ?></td>
                            <td class="td-dashboard"><?php echo e($d->formatted_price); ?></td>
                            <td class="td-dashboard text-center"><?php echo e($d->stock); ?></td>
                            <td class="td-dashboard text-center capitalize"><?php echo e($d->status); ?></td>
                            <td class="td-dashboard text-center space-x-2">
                                <a href="<?php echo e(route('dashboard.admin.products.edit', $d)); ?>" class="text-primary hover:underline">Edit</a>
                                <form action="<?php echo e(route('dashboard.admin.products.destroy', $d)); ?>" method="POST" class="inline" onsubmit="return confirm('Nonaktifkan <?php echo e($d->name); ?>?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-danger hover:underline">Nonaktifkan</button>
                                </form>
                            </td>
                        <?php elseif($tab === 'transactions'): ?>
                            <td class="td-dashboard"><?php echo e($d->invoice_number); ?></td>
                            <td class="td-dashboard"><?php echo e($d->user->name); ?></td>
                            <td class="td-dashboard"><?php echo e($d->formatted_total_amount); ?></td>
                            <td class="td-dashboard text-center capitalize"><?php echo e($d->status); ?></td>
                            <td class="td-dashboard text-center uppercase"><?php echo e($d->payment_method); ?></td>
                            <td class="td-dashboard text-center space-x-2">
                                <a href="<?php echo e(route('dashboard.admin.transactions.detail', $d->invoice_number)); ?>" class="text-primary hover:underline">Detail</a>
                                <?php if($d->status === 'pending'): ?>
                                    <form action="<?php echo e(route('dashboard.admin.transactions.update', $d)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <button type="submit" name="status" value="completed" class="hover:underline" style="color:#7C9473">Konfirmasi</button>
                                        <button type="submit" name="status" value="cancelled" class="text-danger hover:underline">Batal</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td class="td-dashboard text-center" colspan="8">Belum ada data.</td></tr>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760)): ?>
<?php $attributes = $__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760; ?>
<?php unset($__attributesOriginalc38fd2bb5c7e2f0648b923f6c4657760); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760)): ?>
<?php $component = $__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760; ?>
<?php unset($__componentOriginalc38fd2bb5c7e2f0648b923f6c4657760); ?>
<?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/dashboard/admin/index.blade.php ENDPATH**/ ?>