<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Pembayaran <?php $__env->endSlot(); ?>

    <div class="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-sm">
        <h1 class="font-serif text-2xl text-primary mb-6">Pilih Metode Pembayaran</h1>

        <form action="<?php echo e(route('dashboard.user.payment.store')); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-3 gap-3">
                <?php $__currentLoopData = ['qris' => 'QRIS', 'ovo' => 'OVO', 'dana' => 'DANA', 'paypal' => 'PayPal', 'bayar ditempat' => 'Bayar di Tempat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="border border-black/10 rounded-xl p-4 text-center text-sm font-semibold cursor-pointer has-[:checked]:border-accent has-[:checked]:bg-accent/10">
                        <input type="radio" name="payment_method" value="<?php echo e($value); ?>" class="hidden" <?php if($loop->first): echo 'checked'; endif; ?>>
                        <?php echo e($label); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="border-t pt-4 flex justify-between font-bold text-lg">
                <span>Total Bayar</span>
                <span class="text-primary"><?php echo e($formattedGrandTotal); ?></span>
            </div>

            <button type="submit" class="w-full bg-primary text-white py-3 rounded-xl font-bold hover:opacity-90">
                Konfirmasi Pesanan
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/dashboard/user/payment.blade.php ENDPATH**/ ?>