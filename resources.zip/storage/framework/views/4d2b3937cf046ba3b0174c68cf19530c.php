<?php
    $cart = session('cart', []);
    $cartProducts = \App\Models\Product::whereIn('id', array_keys($cart))->get();
    $totalUniqueProducts = $cartProducts->count();
?>

<div id="cart-wrapper" class="relative inline-block group">

    <?php if (isset($component)) { $__componentOriginalc295f12dca9d42f28a259237a5724830 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc295f12dca9d42f28a259237a5724830 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => ''.e(route('dashboard.user.cart')).'','active' => request()->routeIs('dashboard.user.cart')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('dashboard.user.cart')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard.user.cart'))]); ?>
        <div class="flex items-center justify-center relative">
            <span
                class="cart-icon text-2xl group-[.menu-open]:text-primary hover:text-primary transition-all duration-250 group-[.menu-open]:scale-110 icon-[solar--cart-3-bold]"></span>
            <?php if($totalUniqueProducts > 0): ?>
                <span
                    class="absolute -top-2 -right-2 bg-accent text-primary text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                    <?php echo e($totalUniqueProducts); ?>

                </span>
            <?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $attributes = $__attributesOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__attributesOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc295f12dca9d42f28a259237a5724830)): ?>
<?php $component = $__componentOriginalc295f12dca9d42f28a259237a5724830; ?>
<?php unset($__componentOriginalc295f12dca9d42f28a259237a5724830); ?>
<?php endif; ?>

    <div
        class="cart-modal absolute z-20 right-0 h-fit w-80 bg-white shadow-lg border-t-2 border-t-accent text-black px-4 py-4 rounded-tl-2xl rounded-bl-2xl rounded-br-2xl text-xs opacity-0 invisible -translate-y-2
        transition-all duration-250 ease-in-out
        group-[.menu-open]:opacity-100 group-[.menu-open]:visible group-[.menu-open]:translate-y-0">

        <div class="flex flex-col gap-2 border-b border-black/10 pb-2">
            <?php if($totalUniqueProducts > 0): ?>
                <?php $__currentLoopData = $cartProducts->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginala6cae600ce6e76876f21de1efad8bbf7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6cae600ce6e76876f21de1efad8bbf7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.cart-item-hover','data' => ['name' => $product->name,'price' => $product->formatted_price]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.cart-item-hover'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name),'price' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->formatted_price)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6cae600ce6e76876f21de1efad8bbf7)): ?>
<?php $attributes = $__attributesOriginala6cae600ce6e76876f21de1efad8bbf7; ?>
<?php unset($__attributesOriginala6cae600ce6e76876f21de1efad8bbf7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6cae600ce6e76876f21de1efad8bbf7)): ?>
<?php $component = $__componentOriginala6cae600ce6e76876f21de1efad8bbf7; ?>
<?php unset($__componentOriginala6cae600ce6e76876f21de1efad8bbf7); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($totalUniqueProducts > 3): ?>
                    <p class="text-center text-secondary italic py-1">
                        ...dan <?php echo e($totalUniqueProducts - 3); ?> produk lainnya
                    </p>
                <?php endif; ?>
            <?php else: ?>
                <p class="text-center text-secondary py-2">Keranjang kamu masih kosong</p>
            <?php endif; ?>
        </div>

        <div class="mt-3 text-secondary px-2 flex flex-row justify-between items-center">
            <p><?php echo e($totalUniqueProducts); ?> produk di keranjang</p>
            <a href="<?php echo e(route('dashboard.user.cart')); ?>"
                class="bg-primary text-white py-1 px-3 rounded-lg hover:opacity-90 transition font-semibold">
                Lihat
            </a>
        </div>
    </div>
</div><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/components/dashboard/cart-hover.blade.php ENDPATH**/ ?>