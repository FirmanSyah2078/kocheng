<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'price']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'price']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="flex flex-row gap-2 justify-between items-center">
    <div class="flex flex-row gap-2 items-center">
        <div class="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
            <span class="icon-[mdi--paw] text-accent"></span>
        </div>
        <h2 class="font-medium text-[0.9rem]"><?php echo e($name); ?></h2>
    </div>
    <p class="text-primary text-[0.9rem] font-semibold"><?php echo e($price); ?></p>
</div><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/components/dashboard/cart-item-hover.blade.php ENDPATH**/ ?>