<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Keranjang - Meowland <?php $__env->endSlot(); ?>

    <div class="max-w-6xl mx-auto px-6 py-10">
        <h1 class="font-serif text-3xl font-bold text-primary mb-8">Keranjang Belanja</h1>

        <div class="flex flex-col lg:flex-row gap-8">
            <div class="flex-1 space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginal118cdf173392f1e0fd47ef6c382f23f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal118cdf173392f1e0fd47ef6c382f23f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.cart-item','data' => ['product' => $product,'quantity' => $cart[$product->id]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.cart-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'quantity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cart[$product->id])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal118cdf173392f1e0fd47ef6c382f23f1)): ?>
<?php $attributes = $__attributesOriginal118cdf173392f1e0fd47ef6c382f23f1; ?>
<?php unset($__attributesOriginal118cdf173392f1e0fd47ef6c382f23f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal118cdf173392f1e0fd47ef6c382f23f1)): ?>
<?php $component = $__componentOriginal118cdf173392f1e0fd47ef6c382f23f1; ?>
<?php unset($__componentOriginal118cdf173392f1e0fd47ef6c382f23f1); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="bg-white rounded-2xl p-12 text-center text-secondary">
                        Keranjang kamu masih kosong 🐾
                        <a href="<?php echo e(route('dashboard.user.products')); ?>" class="text-accent font-bold block mt-2">Belanja
                            sekarang</a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="w-full lg:w-80 shrink-0">
                <div class="bg-white p-6 rounded-2xl shadow-sm sticky top-24">
                    <h2 class="text-lg font-bold text-primary mb-4">Ringkasan Belanja</h2>
                    <div class="flex justify-between mb-2 text-sm text-secondary">
                        <span>Total Item</span>
                        <span><?php echo e($totalItems); ?></span>
                    </div>
                    <div class="flex justify-between mb-6 text-lg font-bold border-t border-black/10 pt-4">
                        <span>Total Bayar</span>
                        <span class="text-primary"><?php echo e($formattedGrandTotal); ?></span>
                    </div>

                    <a href="<?php echo e($totalItems > 0 ? route('dashboard.user.payment') : '#'); ?>"
                        class="w-full block text-center bg-primary text-white py-3 rounded-xl font-bold hover:opacity-90 transition <?php echo e($totalItems == 0 ? 'opacity-40 pointer-events-none' : ''); ?>">
                        Lanjut ke Pembayaran
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/dashboard/user/cart.blade.php ENDPATH**/ ?>