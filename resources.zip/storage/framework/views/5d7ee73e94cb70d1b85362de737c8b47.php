<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Kontak Kami - Meowland <?php $__env->endSlot(); ?>

    <section class="max-w-2xl mx-auto px-6 py-20 text-center">
        <h1 class="font-serif text-4xl text-primary mb-4">Hubungi Kami</h1>
        <p class="text-secondary mb-10">Ada pertanyaan soal produk atau pesanan? Kontak kami lewat salah satu cara di bawah.</p>

        <div class="bg-white rounded-2xl shadow-sm p-8 grid gap-6 text-left">
            <div>
                <p class="text-xs uppercase font-bold text-accent mb-1">Alamat Toko</p>
                <p class="text-secondary">Isi alamat toko Meowland kamu di sini.</p>
            </div>
            <div>
                <p class="text-xs uppercase font-bold text-accent mb-1">WhatsApp</p>
                <p class="text-secondary">Isi nomor WhatsApp toko kamu di sini.</p>
            </div>
            <div>
                <p class="text-xs uppercase font-bold text-accent mb-1">Jam Operasional</p>
                <p class="text-secondary">Isi jam buka-tutup toko kamu di sini.</p>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/contact.blade.php ENDPATH**/ ?>