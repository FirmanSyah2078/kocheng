<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $categoryIcons = [
        'makanan' => 'icon-[game-icons--canned-fish]',
        'obat' => 'icon-[mdi--medicine-bottle]',
        'alat' => 'icon-[mdi--bowl-mix]',
        'mainan' => 'icon-[mdi--toy-brick]',
    ];
    $icon = $categoryIcons[strtolower($product->category->name ?? '')] ?? 'icon-[mdi--paw]';
?>

<section class="group flex flex-col bg-white rounded-2xl border border-black/5 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 overflow-hidden">
    <div class="h-36 bg-accent/10 flex items-center justify-center">
        <span class="icon-[mdi--paw] text-5xl text-accent/40"></span>
    </div>

    <div class="p-4 flex flex-col flex-1">
        <p class="text-[11px] font-bold uppercase text-accent tracking-wide mb-1"><?php echo e($product->category->name ?? '-'); ?></p>
        <h3 class="font-bold text-primary text-sm truncate mb-1"><?php echo e($product->name); ?></h3>
        <p class="font-bold text-primary mb-3"><?php echo e($product->formatted_price); ?></p>

        <div class="flex items-center justify-between mt-auto">
            <div class="flex items-center gap-1.5 text-xs text-secondary">
                <span class="<?php echo e($icon); ?> text-base"></span>
                <span>Stok <?php echo e($product->stock); ?></span>
            </div>

            <form action="<?php echo e(route('dashboard.user.cart.add', $product)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit"
                    class="bg-primary text-white rounded-tl-xl rounded-br-xl w-10 h-9 flex items-center justify-center group-hover:scale-110 transition-transform disabled:opacity-30"
                    <?php if($product->stock < 1): echo 'disabled'; endif; ?>>
                    <span class="icon-[mdi--basket-fill] text-lg"></span>
                </button>
            </form>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Hype GLK\Desktop\kocheng-fixed\resources\views/components/dashboard/product-card.blade.php ENDPATH**/ ?>