<x-layout>
    <x-slot:title>Tentang Kami - Meowland</x-slot>

    <section class="font-sans-landing bg-neutral-landing max-w-4xl mx-auto px-6 py-20 text-center rounded-3xl">
        <h1 class="font-bold text-4xl text-primary-landing mb-8">Kisah Meowland</h1>
        <div class="bg-white p-10 rounded-2xl shadow-sm text-left leading-relaxed text-secondary-landing">
            <p class="mb-6">
                Meowland lahir dari keinginan untuk memberikan kemudahan bagi para pecinta kucing.
                Kami paham waktumu berharga, tapi kesehatan dan kebahagiaan anabul tetap prioritas utama.
            </p>
            <p>
                Dengan konsep <strong class="text-primary-landing">"Klik Meowland, Ambil di Toko"</strong>,
                kamu cukup pesan dari ponsel, datang ke toko, dan bawa pulang kebahagiaan untuk kucingmu.
            </p>
        </div>
    </section>
</x-layout>