<x-layout>
    <x-slot:title>Kontak Kami - Meowland</x-slot>

    <section class="max-w-2xl mx-auto px-6 py-20 text-center">
        <h1 class="font-serif text-4xl text-primary mb-4">Hubungi Kami</h1>
        <p class="text-secondary mb-10">Ada pertanyaan soal produk atau pesanan? Kontak kami lewat salah satu cara di bawah.</p>

        <div class="bg-white rounded-2xl shadow-sm p-8 grid gap-6 text-left">
            <div>
                <p class="text-xs uppercase font-bold text-accent mb-1">Alamat Toko</p>
                <p class="text-secondary">Isi alamat toko Meowland kamu di sini.</p>
            </div>
            <div>
                <p class="text-xs uppercase font-bold text-accent mb-1">WhatsApp</p>
                <p class="text-secondary">Isi nomor WhatsApp toko kamu di sini.</p>
            </div>
            <div>
                <p class="text-xs uppercase font-bold text-accent mb-1">Jam Operasional</p>
                <p class="text-secondary">Isi jam buka-tutup toko kamu di sini.</p>
            </div>
        </div>
    </section>
</x-layout>
